﻿namespace Praktika
{
    partial class Pupil
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ShowPredmet = new System.Windows.Forms.Button();
            this.Back = new System.Windows.Forms.Button();
            this.ShowRaspisanie = new System.Windows.Forms.Button();
            this.ShowTeachers = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // ShowPredmet
            // 
            this.ShowPredmet.Location = new System.Drawing.Point(12, 138);
            this.ShowPredmet.Name = "ShowPredmet";
            this.ShowPredmet.Size = new System.Drawing.Size(125, 58);
            this.ShowPredmet.TabIndex = 9;
            this.ShowPredmet.Text = "Показать предметы";
            this.ShowPredmet.UseVisualStyleBackColor = true;
            this.ShowPredmet.Click += new System.EventHandler(this.ShowPredmet_Click);
            // 
            // Back
            // 
            this.Back.Location = new System.Drawing.Point(25, 248);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(100, 35);
            this.Back.TabIndex = 8;
            this.Back.Text = "<<Назад";
            this.Back.UseVisualStyleBackColor = true;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // ShowRaspisanie
            // 
            this.ShowRaspisanie.Location = new System.Drawing.Point(13, 10);
            this.ShowRaspisanie.Name = "ShowRaspisanie";
            this.ShowRaspisanie.Size = new System.Drawing.Size(124, 58);
            this.ShowRaspisanie.TabIndex = 7;
            this.ShowRaspisanie.Text = "Показать расписание";
            this.ShowRaspisanie.UseVisualStyleBackColor = true;
            this.ShowRaspisanie.Click += new System.EventHandler(this.ShowRaspisanie_Click);
            // 
            // ShowTeachers
            // 
            this.ShowTeachers.Location = new System.Drawing.Point(13, 74);
            this.ShowTeachers.Name = "ShowTeachers";
            this.ShowTeachers.Size = new System.Drawing.Size(125, 58);
            this.ShowTeachers.TabIndex = 6;
            this.ShowTeachers.Text = "Показать преподавателей";
            this.ShowTeachers.UseVisualStyleBackColor = true;
            this.ShowTeachers.Click += new System.EventHandler(this.ShowTeachers_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(179, 10);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(371, 277);
            this.dataGridView1.TabIndex = 5;
            // 
            // Pupil
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(562, 297);
            this.Controls.Add(this.ShowPredmet);
            this.Controls.Add(this.Back);
            this.Controls.Add(this.ShowRaspisanie);
            this.Controls.Add(this.ShowTeachers);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Pupil";
            this.Text = "Pupil";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button ShowPredmet;
        private System.Windows.Forms.Button Back;
        private System.Windows.Forms.Button ShowRaspisanie;
        private System.Windows.Forms.Button ShowTeachers;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}