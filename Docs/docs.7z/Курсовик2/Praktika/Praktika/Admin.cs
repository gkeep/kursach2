﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Praktika
{
    public partial class Admin : Form
    {
        private readonly string sqlconnection = "Data Source = localhost; Initial Catalog = School; Integrated Security = True";

        public Admin()
        {
            InitializeComponent();
        }

        private void Admin_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "schoolDataSet.Users". При необходимости она может быть перемещена или удалена.
            //this.usersTableAdapter.Fill(this.schoolDataSet.Users);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "schoolDataSet.Class". При необходимости она может быть перемещена или удалена.
            //this.classTableAdapter.Fill(this.schoolDataSet.Class);

        }

        private void ShowClass_Click(object sender, EventArgs e)
        {
            //this.classTableAdapter.Fill(this.schoolDataSet.Class);
            string command = "SELECT FIO, Letter FROM Students INNER JOIN Class ON Id_Class = Class_id;";
            using (SqlConnection connection = new SqlConnection(sqlconnection))
            {
            connection.Open();

                DataTable dt = new DataTable();
                SqlDataAdapter adapter = new SqlDataAdapter(command, connection);

                adapter.Fill(dt);

                dataGridView1.DataSource = dt.DefaultView;

                connection.Close();
            }
        }

        private void ShowUsers_Click(object sender, EventArgs e)
        {
            //this.usersTableAdapter.Fill(this.schoolDataSet.Users);
            string command = "SELECT Nick, Parol FROM Users;";
            using (SqlConnection connection = new SqlConnection(sqlconnection))
            {
                connection.Open();

                DataTable dt = new DataTable();
                SqlDataAdapter adapter = new SqlDataAdapter(command, connection);

                adapter.Fill(dt);

                dataGridView1.DataSource = dt.DefaultView;

                connection.Close();
            }
        }
        private void ShowTeachers_Click(object sender, EventArgs e)
        {
            string command = "SELECT  TitleP, FIO FROM Predmet INNER JOIN Staff ON Id_Staff = Staf_id; ";
            using (SqlConnection connection = new SqlConnection(sqlconnection))
            {
                connection.Open();

                DataTable dt = new DataTable();
                SqlDataAdapter adapter = new SqlDataAdapter(command, connection);

                adapter.Fill(dt);

                dataGridView1.DataSource = dt.DefaultView;

                connection.Close();
            }
        }
        private void Back_Click(object sender, EventArgs e)
        {
            this.Close();
            LoginForm formLogin = new LoginForm();
            formLogin.Show();
        }
    }
}
