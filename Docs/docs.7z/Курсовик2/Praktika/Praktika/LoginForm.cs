﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Praktika
{
    public partial class LoginForm : Form
    {
        private readonly string sqlconnection = "Data Source = localhost; Initial Catalog = School; Integrated Security = True";

        public LoginForm()
        {
            InitializeComponent();

            this.passField.AutoSize = false;
            this.passField.Size = new Size(this.passField.Size.Width, 64);

        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void closeButton_MouseEnter(object sender, EventArgs e)
        {
            closeButton.ForeColor = Color.Red;
        }

        private void closeButton_MouseLeave(object sender, EventArgs e)
        {
            closeButton.ForeColor = Color.White;
        }

        Point lastPoint;
        private void MainPanel_MouseMove(object sender, MouseEventArgs e)
        {
            if(e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void MainPanel_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void TopPanel_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void TopPanel_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string command = $"SELECT Parol FROM Users WHERE Nick = '{loginField.Text}'";
            using (SqlConnection connection = new SqlConnection(sqlconnection))
            {
                connection.Open();

                SqlDataAdapter adapter;
                adapter = new SqlDataAdapter(command, connection);
                DataTable dt = new DataTable();

                try
                {
                    adapter.Fill(dt);

                    string pass = dt.Rows[0][0].ToString();

                    if (pass == passField.Text)
                    {
                        if (loginField.Text == "Admin")
                        {
                            Admin formAdmin = new Admin();
                            formAdmin.Show();
                            this.Hide();
                        }
                        else if (loginField.Text == "Pupil")
                        {
                            Pupil formPupil = new Pupil();
                            formPupil.Show();
                            this.Hide();
                        }
                        else if (loginField.Text == "Teachers")
                        {
                            Teacher formTeacher = new Teacher();
                            formTeacher.Show();
                            this.Hide();
                        }
                    }
                    else MessageBox.Show("Неверный пароль!");
                }
                catch
                {
                    MessageBox.Show("Ошибка в логине!");
                }

                connection.Close();
            }
        }
    }
}
