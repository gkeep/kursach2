﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Praktika
{
    public partial class Pupil : Form
    {
        private readonly string sqlconnection = "Data Source = localhost; Initial Catalog = School; Integrated Security = True";
        public Pupil()
        {
            InitializeComponent();
        }

        private void ShowRaspisanie_Click(object sender, EventArgs e)
        {
            string command = "SELECT DayWeek, TitleP, Letter FROM Raspisanie INNER JOIN Class ON Id_class = Class_id INNER JOIN Predmet ON Id_Predmet = Predmet_id WHERE Letter = 'А' AND DayWeek = 'ПН';";
            using (SqlConnection connection = new SqlConnection(sqlconnection))
            {
                connection.Open();

                DataTable dt = new DataTable();
                SqlDataAdapter adapter = new SqlDataAdapter(command, connection);

                adapter.Fill(dt);

                dataGridView1.DataSource = dt.DefaultView;

                connection.Close();
            }
        }

        private void ShowTeachers_Click(object sender, EventArgs e)
        {
            string command = "SELECT  TitleP, FIO FROM Predmet INNER JOIN Staff ON Id_Staff = Staf_id; ";
            using (SqlConnection connection = new SqlConnection(sqlconnection))
            {
                connection.Open();

                DataTable dt = new DataTable();
                SqlDataAdapter adapter = new SqlDataAdapter(command, connection);

                adapter.Fill(dt);

                dataGridView1.DataSource = dt.DefaultView;

                connection.Close();
            }
        }

        private void ShowPredmet_Click(object sender, EventArgs e)
        {
            string command = "SELECT DayWeek, TitleP, Letter FROM Raspisanie INNER JOIN Class ON Id_class = Class_id INNER JOIN Predmet ON Id_Predmet = Predmet_id; ";
            using (SqlConnection connection = new SqlConnection(sqlconnection))
            {
                connection.Open();

                DataTable dt = new DataTable();
                SqlDataAdapter adapter = new SqlDataAdapter(command, connection);

                adapter.Fill(dt);

                dataGridView1.DataSource = dt.DefaultView;

                connection.Close();
            }
        }

        private void Back_Click(object sender, EventArgs e)
        {
            this.Close();
            LoginForm formLogin = new LoginForm();
            formLogin.Show();
        }
    }
}
