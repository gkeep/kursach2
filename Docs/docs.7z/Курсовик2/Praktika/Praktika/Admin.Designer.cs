﻿namespace Praktika
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ShowClass = new System.Windows.Forms.Button();
            this.ShowUsers = new System.Windows.Forms.Button();
            this.Back = new System.Windows.Forms.Button();
            this.schoolDataSet = new Praktika.SchoolDataSet();
            this.schoolDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.classBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.classTableAdapter = new Praktika.SchoolDataSetTableAdapters.ClassTableAdapter();
            this.usersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.usersTableAdapter = new Praktika.SchoolDataSetTableAdapters.UsersTableAdapter();
            this.ShowTeachers = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.classBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.usersBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(179, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(371, 277);
            this.dataGridView1.TabIndex = 0;
            // 
            // ShowClass
            // 
            this.ShowClass.Location = new System.Drawing.Point(13, 76);
            this.ShowClass.Name = "ShowClass";
            this.ShowClass.Size = new System.Drawing.Size(125, 58);
            this.ShowClass.TabIndex = 1;
            this.ShowClass.Text = "Показать учеников";
            this.ShowClass.UseVisualStyleBackColor = true;
            this.ShowClass.Click += new System.EventHandler(this.ShowClass_Click);
            // 
            // ShowUsers
            // 
            this.ShowUsers.Location = new System.Drawing.Point(13, 12);
            this.ShowUsers.Name = "ShowUsers";
            this.ShowUsers.Size = new System.Drawing.Size(124, 58);
            this.ShowUsers.TabIndex = 2;
            this.ShowUsers.Text = "Показать пользователей";
            this.ShowUsers.UseVisualStyleBackColor = true;
            this.ShowUsers.Click += new System.EventHandler(this.ShowUsers_Click);
            // 
            // Back
            // 
            this.Back.Location = new System.Drawing.Point(25, 250);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(100, 35);
            this.Back.TabIndex = 3;
            this.Back.Text = "<<Назад";
            this.Back.UseVisualStyleBackColor = true;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // schoolDataSet
            // 
            this.schoolDataSet.DataSetName = "SchoolDataSet";
            this.schoolDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // schoolDataSetBindingSource
            // 
            this.schoolDataSetBindingSource.DataSource = this.schoolDataSet;
            this.schoolDataSetBindingSource.Position = 0;
            // 
            // classBindingSource
            // 
            this.classBindingSource.DataMember = "Class";
            this.classBindingSource.DataSource = this.schoolDataSetBindingSource;
            // 
            // classTableAdapter
            // 
            this.classTableAdapter.ClearBeforeFill = true;
            // 
            // usersBindingSource
            // 
            this.usersBindingSource.DataMember = "Users";
            this.usersBindingSource.DataSource = this.schoolDataSetBindingSource;
            // 
            // usersTableAdapter
            // 
            this.usersTableAdapter.ClearBeforeFill = true;
            // 
            // ShowTeachers
            // 
            this.ShowTeachers.Location = new System.Drawing.Point(12, 140);
            this.ShowTeachers.Name = "ShowTeachers";
            this.ShowTeachers.Size = new System.Drawing.Size(125, 58);
            this.ShowTeachers.TabIndex = 4;
            this.ShowTeachers.Text = "Показать преподавателей";
            this.ShowTeachers.UseVisualStyleBackColor = true;
            this.ShowTeachers.Click += new System.EventHandler(this.ShowTeachers_Click);
            // 
            // Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(562, 297);
            this.Controls.Add(this.ShowTeachers);
            this.Controls.Add(this.Back);
            this.Controls.Add(this.ShowUsers);
            this.Controls.Add(this.ShowClass);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Admin";
            this.Text = "Admin";
            this.Load += new System.EventHandler(this.Admin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.classBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.usersBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button ShowClass;
        private System.Windows.Forms.Button ShowUsers;
        private System.Windows.Forms.Button Back;
        private System.Windows.Forms.BindingSource schoolDataSetBindingSource;
        private SchoolDataSet schoolDataSet;
        private System.Windows.Forms.BindingSource classBindingSource;
        private SchoolDataSetTableAdapters.ClassTableAdapter classTableAdapter;
        private System.Windows.Forms.BindingSource usersBindingSource;
        private SchoolDataSetTableAdapters.UsersTableAdapter usersTableAdapter;
        private System.Windows.Forms.Button ShowTeachers;
    }
}